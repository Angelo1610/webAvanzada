import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-registro-variantes',
  standalone: true,  // Marca el componente como standalone
  templateUrl: './registro-variantes.component.html',
  styleUrls: ['./registro-variantes.component.css'],
  imports: [ReactiveFormsModule]  // Importa ReactiveFormsModule aquí
})
export class RegistroVariantesComponent implements OnInit {
  registroForm!: FormGroup;  // Aquí definimos la propiedad del formulario reactivo
  colores: string[] = ['Rojo', 'Azul', 'Verde', 'Negro', 'Blanco'];  // Lista de colores
  tallas: string[] = ['36', '37', '38', '39', '40', '41'];  // Lista de tallas

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    // Inicializamos el formulario con validaciones
    this.registroForm = this.fb.group({
      nombre: ['', Validators.required],
      precio: ['', [Validators.required, Validators.min(0)]],
      variantes: this.fb.group({
        colores: this.fb.group({
          rojo: [false],
          azul: [false],
          verde: [false],
          negro: [false],
          blanco: [false]
        }),
        talla: ['', Validators.required]
      })
    });
  }

  // Función que se ejecuta cuando se envía el formulario
  onSubmit(): void {
    if (this.registroForm.valid) {
      console.log(this.registroForm.value);  // Muestra los datos del formulario
    } else {
      console.log('Formulario no válido');
    }
  }
}
