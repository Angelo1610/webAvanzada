import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';

export interface Producto {
  id: number;
  nombre: string;
  variantes: string[]; // Variantes de colores seleccionados
  marca: string;
  precio: number;
  stock: number;
}

@Component({
  selector: 'app-gestion-inventario',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './gestion-inventario.component.html',
  styleUrls: ['./gestion-inventario.component.css']
})
export class GestionInventarioComponent {
  inventarioForm: FormGroup;
  productos: Producto[] = [];

  colores: string[] = ['Rojo', 'Azul', 'Negro'];
  tallas: string[] = ['36', '37', '38', '39', '40'];

  constructor(private fb: FormBuilder) {
    // Creamos el formulario con validaciones
    this.inventarioForm = this.fb.group({
      nombre: ['', Validators.required],
      marca: ['', Validators.required],
      variantes: this.fb.group({
        colores: this.fb.group(
          // Especificamos el tipo de acc como un objeto con claves de tipo string y valores de tipo FormControl
          this.colores.reduce((acc: Record<string, FormControl>, color) => {
            acc[color] = new FormControl(false); // Inicializamos con false
            return acc;
          }, {})
        ),
        talla: ['', Validators.required]
      }),
      precio: ['', [Validators.required, Validators.min(0.01)]],
      stock: ['', [Validators.required, Validators.min(0), this.stockValidator]]
    });
  }

  // Validación personalizada para el stock
  stockValidator(control: FormControl) {
    const value = control.value;
    if (value < 0) {
      return { stockInvalido: true }; // Si el valor es menor que 0, se considera inválido
    }
    if (isNaN(value)) {
      return { stockInvalido: true }; // Si no es un número, también es inválido
    }
    return null;
  }

  onSubmit() {
    if (this.inventarioForm.valid) {
      const formValue = this.inventarioForm.value;
      const coloresSeleccionados = Object.keys(formValue.variantes.colores)
        .filter(color => formValue.variantes.colores[color]);

      const nuevoProducto: Producto = {
        id: Date.now(),
        nombre: formValue.nombre,
        variantes: coloresSeleccionados,
        marca: formValue.marca,
        precio: formValue.precio,
        stock: formValue.stock
      };

      this.productos.push(nuevoProducto);
      this.inventarioForm.reset(); // Reseteamos el formulario después de agregar el producto
    }
  }
}
