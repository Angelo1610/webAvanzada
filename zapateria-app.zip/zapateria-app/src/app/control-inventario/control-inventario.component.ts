import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
// control-inventario.component.ts
import { Producto } from '../gestion-inventario/gestion-inventario.component'; // Ajusta según la ubicación del archivo

@Component({
  selector: 'app-control-inventario',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './control-inventario.component.html',
  styleUrls: ['./control-inventario.component.css']
})
export class ControlInventarioComponent {
  controlForm: FormGroup;
  productos: Producto[] = []; // Asegúrate de tener los productos disponibles

  constructor(private fb: FormBuilder) {
    this.controlForm = this.fb.group({
      producto: ['', Validators.required],
      tipoOperacion: ['', Validators.required],
      cantidad: ['', [Validators.required, Validators.min(1)]],
      fecha: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.controlForm.valid) {
      const formValue = this.controlForm.value;
      const productoSeleccionado = this.productos.find(p => p.id === formValue.producto);

      if (productoSeleccionado) {
        if (formValue.tipoOperacion === 'Salida' && formValue.cantidad > productoSeleccionado.stock) {
          alert('No hay suficiente stock para realizar la salida');
        } else {
          // Actualizamos el stock dependiendo de la operación
          if (formValue.tipoOperacion === 'Entrada') {
            productoSeleccionado.stock += formValue.cantidad;
          } else if (formValue.tipoOperacion === 'Salida') {
            productoSeleccionado.stock -= formValue.cantidad;
          }
          alert('Operación realizada con éxito');
        }
      }
      this.controlForm.reset();
    }
  }
}
