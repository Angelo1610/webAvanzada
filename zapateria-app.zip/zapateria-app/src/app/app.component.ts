import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';  // Importa RouterModule

import { ControlInventarioComponent } from './control-inventario/control-inventario.component';
import { RegistroVariantesComponent } from './registro-variantes/registro-variantes.component';
import { GestionInventarioComponent } from './gestion-inventario/gestion-inventario.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterModule, ControlInventarioComponent, RegistroVariantesComponent, GestionInventarioComponent],  // Asegúrate de incluir RouterModule
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Zapatería App';  // Define la propiedad 'title'
}
