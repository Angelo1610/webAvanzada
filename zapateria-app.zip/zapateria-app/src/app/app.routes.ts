import { Routes } from '@angular/router';
import { GestionInventarioComponent } from './gestion-inventario/gestion-inventario.component';
import { ControlInventarioComponent } from './control-inventario/control-inventario.component';
import { RegistroVariantesComponent } from './registro-variantes/registro-variantes.component';

export const routes: Routes = [
  { path: 'gestion-inventario', component: GestionInventarioComponent },
  { path: 'control-inventario', component: ControlInventarioComponent },
  { path: 'registro-variantes', component: RegistroVariantesComponent },
  { path: '', redirectTo: '/gestion-inventario', pathMatch: 'full' }
];
