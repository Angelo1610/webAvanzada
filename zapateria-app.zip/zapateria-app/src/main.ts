import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter } from '@angular/router';
import { routes } from './app/app.routes';
import { GestionInventarioComponent } from './app/gestion-inventario/gestion-inventario.component';

bootstrapApplication(GestionInventarioComponent, {
  providers: [
    provideRouter(routes) // Configuración de rutas
  ]
}).catch(err => console.error(err));
