import { Component } from '@angular/core';

@Component({
  selector: 'app-mora',
  templateUrl: './mora.component.html',
  styleUrls: ['./mora.component.css'] // Corregido: styleUrls en plural
})
export class MoraComponent {}
