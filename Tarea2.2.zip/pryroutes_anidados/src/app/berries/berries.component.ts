import { Component } from '@angular/core';

@Component({
  selector: 'app-berries',
  standalone: true,
  templateUrl: './berries.component.html',
  styleUrls: ['./berries.component.css']
})
export class BerriesComponent {}
