import { Component } from '@angular/core';

@Component({
  selector: 'app-frambuesa',
  templateUrl: './frambuesa.component.html',
  styleUrls: ['./frambuesa.component.css'] // Corregido: styleUrls en plural
})
export class FrambuesaComponent {}
