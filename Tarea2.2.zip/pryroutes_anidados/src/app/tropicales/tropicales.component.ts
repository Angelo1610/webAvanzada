import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';  // Importa lo necesario

@Component({
  selector: 'app-tropicales',
  standalone: true,  // Asegúrate de que el componente sea standalone
  imports: [RouterOutlet, RouterLink],  // Incluye esto solo si lo necesitas
  templateUrl: './tropicales.component.html',
  styleUrls: ['./tropicales.component.css']
})
export class TropicalsComponent {}
