import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-papaya',
  templateUrl: './papaya.component.html',
  styleUrls: ['./papaya.component.css']
})
export class PapayaComponent {
  papayaForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.papayaForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  onSubmit() {
    if (this.papayaForm.valid) {
      console.log(this.papayaForm.value);
    }
  }
}
