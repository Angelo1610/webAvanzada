import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TropicalsComponent } from './tropicales.component';

describe('TropicalsComponent', () => {
  let component: TropicalsComponent;
  let fixture: ComponentFixture<TropicalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TropicalsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TropicalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
