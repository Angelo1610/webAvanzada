import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-mango',
  templateUrl: './mango.component.html',
  styleUrls: ['./mango.component.css']
})
export class MangoComponent {
  mangoForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.mangoForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  onSubmit() {
    if (this.mangoForm.valid) {
      console.log(this.mangoForm.value);
    }
  }
}
