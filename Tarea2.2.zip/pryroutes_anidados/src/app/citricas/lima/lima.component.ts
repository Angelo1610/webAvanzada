import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-lima',
  templateUrl: './lima.component.html',
  styleUrls: ['./lima.component.css']
})
export class LimaComponent {
  limaForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.limaForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  onSubmit() {
    if (this.limaForm.valid) {
      console.log(this.limaForm.value);
    }
  }
}
