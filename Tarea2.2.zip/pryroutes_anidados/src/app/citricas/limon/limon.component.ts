import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-limon',
  templateUrl: './limon.component.html',
  styleUrls: ['./limon.component.css']
})
export class LimonComponent {
  limonForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.limonForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', [Validators.required, Validators.minLength(10)]]
    });
  }

  onSubmit() {
    if (this.limonForm.valid) {
      console.log(this.limonForm.value);
    }
  }
}
