import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';

@Component({
  selector: 'app-citricas',
  standalone: true,
  imports: [RouterOutlet, RouterLink],
  templateUrl: './citricas.component.html',
  styleUrls: ['./citricas.component.css']
})
export class CitricasComponent {}
