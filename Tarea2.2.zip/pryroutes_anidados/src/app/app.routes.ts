import { Routes } from '@angular/router';
import { TropicalsComponent } from './tropicales/tropicales.component';
import { MangoComponent } from './tropicales/mango/mango.component';
import { PapayaComponent } from './tropicales/papaya/papaya.component';
import { CitricasComponent } from './citricas/citricas.component';
import { LimaComponent } from './citricas/lima/lima.component';
import { LimonComponent } from './citricas/limon/limon.component';

export const routes: Routes = [
  {
    path: 'tropicales',
    component: TropicalsComponent,
    children: [
      { path: 'mango', component: MangoComponent },
      { path: 'papaya', component: PapayaComponent },
    ],
  },
  {
    path: 'citricas',
    component: CitricasComponent,
    children: [
      { path: 'lima', component: LimaComponent },
      { path: 'limon', component: LimonComponent },
    ],
  },
  { path: '', redirectTo: '/tropicales', pathMatch: 'full' }, // Redirige a 'tropicales' por defecto
];
