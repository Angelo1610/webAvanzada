import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';  // Importa RouterModule
import { routes } from './app.routes';  // Importa las rutas

@Component({
  selector: 'app-root',
  standalone: true,  // Indica que este componente es standalone
  imports: [RouterModule],  // Importa RouterModule para el enrutamiento
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {}
