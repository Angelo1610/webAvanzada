import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductosService {
 
  private googleDriveUrl: string = 'https://drive.google.com/uc?export=download&id=1BEUPTxkhbPD2JpJZsoZP8kh6wC9Tdxu3 ';


  constructor(private http: HttpClient) {}


  getProductos(): Observable<any> {
    return this.http.get<any>(this.googleDriveUrl);
  }
}
