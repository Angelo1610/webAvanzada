const express = require('express');
const ReservaController = require('../controllers/reservas.controller'); // Asegúrate de que esta ruta sea correcta
const router = express.Router();

// Ruta para obtener todas las reservas
router.get('/', ReservaController.obtenerTodas);

// Ruta para crear una nueva reserva
router.post('/', ReservaController.crear);

// Ruta para obtener una reserva por ID
router.get('/:id', ReservaController.obtenerPorId);

router.put('/:id', ReservaController.actualizar);


// Ruta para eliminar una reserva por ID
router.delete('/:id', ReservaController.eliminar);  // Asegúrate de que esta línea esté presente

module.exports = router;
